const Config = {
    BASE_URL:'/b7-Frontend-Zero-Ao-Pro/Mod14-react-redux/aula26react2/public'
}

export default Config;