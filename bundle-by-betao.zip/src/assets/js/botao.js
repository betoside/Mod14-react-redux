import React, { Component} from 'react';
import ReactDOM from 'react-dom';

class Botao extends Component{
    render(){
        return(
            <button>Clique aqui</button>
        );
    }
}

export default Botao;